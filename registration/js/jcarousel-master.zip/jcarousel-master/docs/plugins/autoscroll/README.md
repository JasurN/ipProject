Autoscroll Plugin
=================

The jCarousel Autoscroll Plugin provides autoscrolling support for jCarousel.

Reference
---------

* [Installation](reference/installation.md)
* [Configuration](reference/configuration.md)
* [API](reference/api.md)
* [Events](reference/events.md)

