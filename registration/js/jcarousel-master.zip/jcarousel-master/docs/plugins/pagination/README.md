Pagination Plugin
=================

The jCarousel Pagination Plugin provides a pagination for jCarousel.

Reference
---------

* [Installation](reference/installation.md)
* [Configuration](reference/configuration.md)
* [API](reference/api.md)
* [Events](reference/events.md)
